<style type="text/css">
<!--
.style1 {
	color: #FF0000;
	font-weight: bold;
}
-->
</style>
<form action="process.php?action=selectPlan" method="post">

<table width="600" border="0" align="center" cellpadding="5" cellspacing="1" bgcolor="#336699" class="entryTable">
  <tr id="entryTableHeader">
    <td>:: Select Plans::</td>
  </tr>
  <tr>
    <td class="contentArea"><div class="errorMessage" align="center"></div>
        <table width="100%" border="0" cellpadding="2" cellspacing="1" class="text">
          <tr align="center">
            <td colspan="2">&nbsp;</td>
          </tr>
          <tr class="entryTable">
            <td class="label">&nbsp;<br/><span class="style1">Basic Plan</span> (60 Channels)<br/><br/>
			<input type="checkbox" name="plan[]" value="120">120 Rs./Month</input></td>
            <td class="content"><p><a href="http://www.indiatvlist.com/dd-malayalam/c1/ch111"><img border="0" width="77" height="37" src="images/channels/clip_image001.gif" alt="DD Malayalam" /></a><a href="http://www.indiatvlist.com/dd-national/c1/ch28"><img border="0" width="77" height="37" src="images/channels/clip_image002.gif" alt="DD National" /></a><a href="http://www.indiatvlist.com/dd-news/c6/ch29"><img border="0" width="77" height="37" src="images/channels/clip_image003.gif" alt="DD News" /></a><a href="http://www.indiatvlist.com/dd-sports/c3/ch31"><img border="0" width="77" height="37" src="images/channels/clip_image004.gif" alt="DD Sports" /></a>&nbsp;<br />
                  <a href="http://www.indiatvlist.com/dd-urdu/c8/ch102"><img border="0" width="77" height="37" src="images/channels/clip_image005.gif" alt="DD Urdu" /></a><a href="http://www.indiatvlist.com/e-tv/c8/ch51"><img border="0" width="77" height="37" src="images/channels/clip_image006.gif" alt="E-TV" /></a><a href="http://www.indiatvlist.com/etv-urdu/c8/ch124"><img border="0" width="77" height="37" src="images/channels/clip_image007.gif" alt="ETV Urdu" /></a><a href="http://www.indiatvlist.com/etv-marathi/c8/ch121"><img border="0" width="77" height="37" src="images/channels/clip_image008.gif" alt="ETV Marathi" /></a><br />
                  <a href="http://www.indiatvlist.com/udaya-movies/c7/ch133/date2010-12-18"><img border="0" width="77" height="37" src="images/channels/clip_image009.gif" alt="http://www.indiatvlist.com/tv_logo/udaya-movies.gif" /></a><a href="http://www.indiatvlist.com/utvi/c6/ch140"><img border="0" width="77" height="37" src="images/channels/clip_image010.gif" alt="UTVI" /></a>&nbsp;<a href="http://www.indiatvlist.com/world-movies/c7/ch70"><img border="0" width="77" height="37" src="images/channels/clip_image011.gif" alt="World Movies" /></a>&nbsp;<a href="http://www.indiatvlist.com/ndtv/c2/ch47"><img border="0" width="60" height="48" src="images/channels/clip_image013.jpg" alt="NDTV" /></a>&nbsp; &nbsp;</p>
              <p>&nbsp;<a href="http://www.indiatvlist.com/ndtv-good-times/c1/ch12"><img border="0" width="77" height="37" src="images/channels/clip_image014.gif" alt="NDTV GOOD TIMES" /></a>&nbsp;<a href="http://www.indiatvlist.com/jaya-tv/c1/ch107"><img border="0" width="77" height="37" src="images/channels/clip_image015.gif" alt="Jaya Tv" /></a>&nbsp;<a href="http://www.indiatvlist.com/star-pravah/c1/ch147"><img border="0" width="77" height="37" src="images/channels/clip_image017.gif" alt="Star Pravah" /></a>&nbsp;<a href="http://www.indiatvlist.com/filmy-channel/c7/ch142"><img border="0" width="77" height="37" src="images/channels/clip_image018.gif" alt="Filmy Channel" /></a>&nbsp;&nbsp;<a href="http://www.indiatvlist.com/udaya-tv/c8/ch130"><img border="0" width="77" height="37" src="images/channels/clip_image019.gif" alt="Udaya TV" /></a></p>
              <p>&nbsp;<a href="http://www.indiatvlist.com/ne-hifi/c1/ch94/date2010-12-18"><img border="0" width="77" height="37" src="images/channels/clip_image020.gif" alt="http://indiatvlist.com/tv_logo/ne-hifi.gif" /></a><a href="http://www.indiatvlist.com/ndtv-arabia/c2/ch108"><img border="0" width="77" height="37" src="images/channels/clip_image021.gif" alt="NDTV Arabia" /></a>&nbsp;&nbsp;<a href="http://www.indiatvlist.com/nepal-1/c8/ch154"><img border="0" width="77" height="37" src="images/channels/clip_image022.gif" alt="Nepal 1" /></a>&nbsp;<a href="http://www.indiatvlist.com/subhavaartha/c1/ch141/date2010-12-18"><img border="0" width="77" height="37" src="images/channels/clip_image023.gif" alt="http://indiatvlist.com/tv_logo/subhavartha_tv.gif" /></a>&nbsp;&nbsp;<a href="http://www.indiatvlist.com/vh1/c1/ch86"><img border="0" width="77" height="37" src="images/channels/clip_image024.gif" alt="Vh1" /></a>&nbsp;</p>
              <p><a href="http://www.indiatvlist.com/tv5-monde/c6/ch23"><img border="0" width="77" height="37" src="images/channels/clip_image025.gif" alt="TV5-monde" /></a>&nbsp;<a href="http://www.indiatvlist.com/kiran-tv/c8/ch137"><img border="0" width="77" height="37" src="images/channels/clip_image026.gif" alt="Kiran TV" /></a>&nbsp;&nbsp;<a href="http://www.indiatvlist.com/rakshana-tv/c8/ch181"><img border="0" width="77" height="37" src="images/channels/clip_image028.gif" alt="Rakshana tv" /></a>&nbsp;&nbsp;<a href="http://www.indiatvlist.com/star-utsav/c1/ch38"><img border="0" width="77" height="37" src="images/channels/clip_image029.gif" alt="Star Utsav" /></a>&nbsp;<a href="http://www.indiatvlist.com/b4u-movies/c7/ch10"><img border="0" width="77" height="37" src="images/channels/clip_image030.gif" alt="B4U Movies" /></a>&nbsp;</p>
              <p>&nbsp;<a href="http://www.indiatvlist.com/jaya-plus/c1/ch4"><img border="0" width="77" height="37" src="images/channels/clip_image032.jpg" alt="Jaya plus" /></a>&nbsp;<a href="http://www.indiatvlist.com/makkal-tv/c8/ch190"><img border="0" width="77" height="37" src="images/channels/clip_image033.gif" alt="Makkal TV" /></a>&nbsp;<a href="http://www.indiatvlist.com/zee-next/c2/ch66"><img border="0" width="77" height="37" src="images/channels/clip_image034.gif" alt="Zee Next" /></a>&nbsp;<a href="http://www.indiatvlist.com/colors-viacom-18/c1/ch1"><img border="0" width="77" height="37" src="images/channels/clip_image035.gif" alt="Colors - Viacom 18" /></a>&nbsp;<a href="http://www.indiatvlist.com/dd-loksabha/c1/ch112"><img border="0" width="77" height="37" src="images/channels/clip_image036.gif" alt="DD Loksabha" /></a>&nbsp;&nbsp;&nbsp;</p>
              <p><a href="http://www.indiatvlist.com/space-tv/c2/ch184"><img border="0" width="77" height="37" src="images/channels/clip_image037.gif" alt="Space TV" /></a>&nbsp;&nbsp;<a href="http://www.indiatvlist.com/sanskar-tv/c9/ch76"><img border="0" width="77" height="37" src="images/channels/clip_image038.gif" alt="Sanskar TV" /></a>&nbsp;<a href="http://www.indiatvlist.com/god/c1/ch34"><img border="0" width="77" height="37" src="images/channels/clip_image039.gif" alt="God" /></a><a href="http://www.indiatvlist.com/sneha-tv/c6/ch2"><img border="0" width="77" height="37" src="images/channels/clip_image040.gif" alt="Sneha TV" /></a>&nbsp;<a href="http://www.indiatvlist.com/shalom-tv/c9/ch72"><img border="0" width="77" height="37" src="images/channels/clip_image041.gif" alt="Shalom Tv" /></a></p>
              <p>&nbsp;<a href="http://www.indiatvlist.com/star-jalsa/c8/ch82"><img border="0" width="77" height="37" src="images/channels/clip_image043.jpg" alt="Star Jalsa" /></a>&nbsp;<a href="http://www.indiatvlist.com/saadhana-tv/c9/ch93"><img border="0" width="77" height="37" src="images/channels/clip_image044.gif" alt="Saadhana TV" /></a>&nbsp;<a href="http://www.indiatvlist.com/tarang-tv/c1/ch193"><img border="0" width="77" height="37" src="images/channels/clip_image045.gif" alt="Tarang TV" /></a>&nbsp;<a href="http://www.indiatvlist.com/topper-tv/c2/ch194"><img border="0" width="77" height="37" src="images/channels/clip_image046.gif" alt="Topper TV" /></a>&nbsp;<a href="http://www.indiatvlist.com/tv-asia/c1/ch180"><img border="0" width="77" height="37" src="images/channels/clip_image047.gif" alt="TV ASIA" /></a></p>                 </tr>
          <tr class="entryTable">
            <td class="label"><span class="style1">Music Plan</span> (12 Channels)<br/>
              <br/>
              <input name="plan[]" type="checkbox" id="plan[]" value="30" />
              30 Rs./Month
            </input></td>
            <td class="content"><p><a href="http://www.indiatvlist.com/channelv/c1/ch44"><img border="0" width="77" height="37" src="images/channels/clip_image001.gif" alt="Channel[V]" /></a><a href="http://www.indiatvlist.com/e-24/c6/ch92"><img border="0" width="77" height="37" src="images/channels/clip_image002.gif" alt="E-24" /></a>&nbsp; <a href="http://www.indiatvlist.com/mtv/c5/ch80"><img border="0" width="77" height="37" src="images/channels/clip_image003.gif" alt="MTV" /></a>&nbsp;&nbsp;<a href="http://www.indiatvlist.com/k-tv/c8/ch127"><img border="0" width="77" height="37" src="images/channels/clip_image004.gif" alt="K TV" /></a>&nbsp;&nbsp;<a href="http://www.indiatvlist.com/music-india/c5/ch98"><img border="0" width="77" height="37" src="images/channels/clip_image005.gif" alt="Music India" /></a></p>
            <p><a href="http://www.indiatvlist.com/tara-muzik/c5/ch68"><img border="0" width="77" height="37" src="images/channels/clip_image006.gif" alt="Sun Music" /><img border="0" width="77" height="37" src="images/channels/clip_image007.gif" alt="Tara Muzik" /></a><a href="http://www.indiatvlist.com/ss-music/c5/ch3"><img border="0" width="77" height="37" src="images/channels/clip_image008.gif" alt="SS Music" /></a>&nbsp;&nbsp;<a href="http://www.indiatvlist.com/jus-punjabi-tv/c8/ch182"><img border="0" width="77" height="37" src="images/channels/clip_image010.gif" alt="Jus Punjabi TV" /></a>&nbsp;<a href="http://www.indiatvlist.com/raj-musix/c5/ch104"><img border="0" width="77" height="37" src="images/channels/clip_image012.gif" alt="Raj Musix" /></a></p>
            <p><a href="http://www.indiatvlist.com/sangeet-bhojpuri/c1/ch164"><img border="0" width="77" height="37" src="images/channels/clip_image013.gif" alt="Sangeet Bhojpuri" /></a><a href="http://www.indiatvlist.com/zee-music/c5/ch148"><img border="0" width="77" height="37" src="images/channels/clip_image014.gif" alt="Zee Music" /></a>&nbsp; </p></td>
          </tr>

          <tr class="entryTable">
            <td valign="top" class="label"><span class="style1">Movie Plan</span> (20 Channels)<br/>
              <br/>
              <input name="plan[]" type="checkbox" id="plan[]" value="100" />
100 Rs./Month
</input></td>
            <td class="content"><p><a href="http://www.indiatvlist.com/news-live/c6/ch199"><img border="0" width="77" height="37" src="images/channels/clip_image001.gif" alt="News Live" /></a><a href="http://www.indiatvlist.com/ndtv-india/c6/ch49"><img border="0" width="77" height="37" src="images/channels/clip_image002.gif" alt="NDTV India" /></a>&nbsp;<a href="http://www.indiatvlist.com/live-india/c6/ch168"><img border="0" width="77" height="37" src="images/channels/clip_image003.gif" alt="Live India" /></a>&nbsp;<a href="http://www.indiatvlist.com/geo-news/c6/ch175"><img border="0" width="77" height="37" src="images/channels/clip_image005.gif" alt="Geo News" /></a>&nbsp;<a href="http://www.indiatvlist.com/ibn-lokmat/c6/ch179"><img border="0" width="77" height="37" src="images/channels/clip_image006.gif" alt="IBN Lokmat" /></a></p>
            <p><a href="http://www.indiatvlist.com/ibn7/c6/ch79"><img border="0" width="77" height="37" src="images/channels/clip_image007.gif" alt="IBN7" /></a><a href="http://www.indiatvlist.com/ne-news/c6/ch163"><img border="0" width="77" height="37" src="images/channels/clip_image008.gif" alt="Ne News" /></a><a href="http://www.indiatvlist.com/jaihind-tv/c1/ch26"><img border="0" width="77" height="37" src="images/channels/clip_image009.gif" alt="Jaihind tv" /></a>&nbsp;<a href="http://www.indiatvlist.com/newsx/c6/ch6"><img border="0" width="77" height="37" src="images/channels/clip_image010.jpg" alt="NewsX" /></a>&nbsp;&nbsp; <a href="http://www.indiatvlist.com/sun-news/c6/ch131"><img border="0" width="77" height="37" src="images/channels/clip_image001_0000.gif" alt="Sun News" /></a></p>
            <p><a href="http://www.indiatvlist.com/real-estate-tv-india/c2/ch192"><img border="0" width="77" height="37" src="images/channels/clip_image002_0000.gif" alt="Real Estate TV India" /></a><a href="http://www.indiatvlist.com/tara-news/c6/ch69"><img border="0" width="77" height="37" src="images/channels/clip_image003_0000.gif" alt="Tara News" /></a><a href="http://www.indiatvlist.com/zee-news/c6/ch67"><img border="0" width="77" height="37" src="images/channels/clip_image004.gif" alt="Zee News" /></a><a href="http://www.indiatvlist.com/times-now/c6/ch95"><img border="0" width="77" height="37" src="images/channels/clip_image005_0000.gif" alt="Times Now" /></a><a href="http://www.indiatvlist.com/asianet-news/c8/ch22"><img border="0" width="77" height="37" src="images/channels/clip_image006_0000.gif" alt="Asianet news" /></a></p>
            <p><a href="http://www.indiatvlist.com/cnbc-awaaz/c6/ch178"><img border="0" width="77" height="37" src="images/channels/clip_image007_0000.gif" alt="CNBC Awaaz" /></a> </p></td>
          </tr>


          <tr>
            <td width="200" class="content"><span class="label"><span class="style1">Knowledge Plan</span> (12 Channels)<br/>
                <br/>
                <input type="checkbox" name="plan[]" value="50" />
50 Rs./Month
</input>
            </span></td>
            <td width="372"><a href="http://www.indiatvlist.com/the-miracle-channel/c9/ch20"><img border="0" width="77" height="37" src="images/channels/clip_image001_0000.gif" alt="The Miracle Channel" /></a><a href="http://www.indiatvlist.com/sudarshan/c9/ch165"><img border="0" width="77" height="37" src="images/channels/clip_image002_0000.gif" alt="Sudarshan" /></a><a href="http://www.indiatvlist.com/animal-planet/c2/ch15"><img border="0" width="77" height="37" src="images/channels/clip_image003_0000.gif" alt="Animal planet" /></a><a href="http://www.indiatvlist.com/discovery-health/c2/ch16"><img border="0" width="77" height="37" src="images/channels/clip_image005.jpg" alt="Discovery Health" /></a>&nbsp; <a href="http://www.indiatvlist.com/the-history-channel/c2/ch41"><img border="0" width="77" height="37" src="images/channels/clip_image006_0000.gif" alt="The History Channel" /></a>&nbsp;<a href="http://www.indiatvlist.com/travelliving/c2/ch71"><img border="0" width="77" height="37" src="images/channels/clip_image007_0000.gif" alt="Travel&amp;Living" /></a><a href="http://www.indiatvlist.com/care-world/c2/ch17"><img border="0" width="77" height="37" src="images/channels/clip_image008_0000.gif" alt="Care world" /></a><a href="http://www.indiatvlist.com/cnn-ibn/c6/ch90"><img border="0" width="77" height="37" src="images/channels/clip_image009_0000.gif" alt="CNN-IBN" /></a><a href="http://www.indiatvlist.com/national-geographic-channel/c2/ch42"><img border="0" width="77" height="37" src="images/channels/clip_image010.gif" alt="National Geographic channel" /></a><a href="http://www.indiatvlist.com/nat-geo-adventure/c2/ch43"><img border="0" width="56" height="37" src="images/channels/clip_image012_0000.gif" alt="Nat geo adventure" /></a>&nbsp;&nbsp; </td>
          </tr>
          <tr>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
          </tr>
          <tr>
            <td>&nbsp;</td>
            <td><input name="btnLogin" type="submit" id="btnLogin"  style="padding:4px 10px;color:#990000;font-weight:bold;" value="Select Plan(s)"></td>
          </tr>
      </table></td>
  </tr>
</table>
</form>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>