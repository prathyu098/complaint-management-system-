<style>
.xyz {
	-moz-border-radius:10px;
	border:#CC9900 solid 1px;
	background-color:#FFFFFF;
	padding:10px;
	width:280px;
	float:left;
	margin-right:30px;
}
.xh2 {
	color:#000033;
	font-size:14px;
}
.xli {
line-height:20px;
}
</style>

<p>&nbsp;</p>
<div class="xyz">
<h2 class="xh2">
Complain Status Details
<ul>
<a href="view.php?mod=admin&view=repo&id=open"><li class="xli">Open Complains</li></a>
<a href="view.php?mod=admin&view=repo&id=close"><li class="xli">Close Complains</li></a>
<a href="view.php?mod=admin&view=repo&id=working"><li class="xli">Working Complains</li></a>
<a href="view.php?mod=admin&view=repo&id=assign"><li class="xli">Assigned Complains</li></a>
</ul>
</h2>
</div>
<div class="xyz">
<h2 class="xh2">
Detail Reports
<ul>
<a href="view.php?mod=admin&view=repod&id=engineer"><li class="xli">Employee Details</li></a>
<a href="view.php?mod=admin&view=repod&id=customer"><li class="xli">Customer Details</li></a>
<a href="view.php?mod=admin&view=repod&id=plans"><li class="xli">Plan Details</li></a>

</ul>
</h2>
</div>