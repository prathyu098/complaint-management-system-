<style>
.xyz {
	border:#333333 solid 1px;
	background-color:#CCCCCC;
	padding:10px;
}
.xh2 {
	color:#000033;
	font-size:14px;
}
</style>
<div class="xyz">
<h2 class="xh2">You already subscribed to a Plan.</h2>
</div>
<p>&nbsp;</p>
